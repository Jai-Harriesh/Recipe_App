import React from 'react'

function NavbarComp() {
  return (
    <nav className="navbar navbar-light bg-warning">
    <div className="container-fluid">
      <h2 className="navbar-brand">MasterChef Recipes</h2>
    </div>
  </nav>
  )
}

export default NavbarComp