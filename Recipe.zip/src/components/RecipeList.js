import React from "react";
import "../styles/recipeList.css";
function RecipeList({ allRecipeData, getSelectedDish }) {
  // console.log("getSelectedDish", getSelectedDish);
  return (
    <div className="recipe-list-container">
      {allRecipeData.map((value, index) => {
        return (
          <div
            className="card recipeListCard cursor-pointer"
            style={{ width: "18rem" }}
            key={index}
            onClick={() => {
              getSelectedDish(value);
            }}
          >
            <img
              src={value.imgURL}
              className="card-img-top"
              alt={value.dishName}
            />
            <div className="card-body">
              <h5 className="card-title">{value.dishName}</h5>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default RecipeList;
