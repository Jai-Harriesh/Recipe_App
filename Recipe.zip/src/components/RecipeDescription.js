import React from 'react'

function RecipeDescription({selectedDish}) {
  return (
    <div className="card" style={{width: '90%'}}>
        <img height={400} width={600} src={selectedDish.imgURL} className="card-img-top" alt="..." />
        <div className="card-body">
          <h5 className="card-title">{selectedDish.dishName}</h5>
          <p className="card-text">{selectedDish.description}</p>
        </div>
      </div>
  )
}

export default RecipeDescription