import './App.css';
import { useState } from 'react';
import RecipeList from './components/RecipeList';
import NavbarComp from './components/NavbarComp';
import RecipeDescription from './components/RecipeDescription';
function App() {
  const [allRecipeData, setallRecipeData] = useState(
    [
      {
        "id": 1,
        "dishName": "Gulab Jamun",
        "imgURL": "https://aartimadan.com/wp-content/uploads/2020/11/milk-powder-gulab-jamuns.jpg",
        "description": "Combine sugar and water in a pan and bring to a boil to create the syrup. Remove from heat, add cardamom, and set aside to cool. In a mixing bowl, combine flour, paneer, sooji, Nestlé MILKMAID, baking powder, and baking soda. Mix gently to form a soft dough avoiding over-kneading. Divide the dough into 30-35 portions and gently shape them into round balls. Heat oil on low flame and fry the balls until they turn golden brown. Transfer the fried Gulab Jamuns into the cooled sugar syrup. Once all the Gulab Jamuns are added, bring the syrup to a boil again briefly, then remove from heat. Enjoy your homemade Gulab Jamun warm, garnished with your favourite toppings."
      },
      {
        "id": 2,
        "dishName": "Biryani",
        "imgURL": "https://t3.ftcdn.net/jpg/01/14/51/60/360_F_114516029_Z2B6FO30AB6ZR3v9WHXjpXmJScaiLtzk.jpg",
        "description": "Biryani is a fragrant rice dish layered with marinated meat, cooked with spices, and finished with caramelized onions and fresh herbs. Traditionally prepared in a sealed pot to allow the flavors to meld beautifully, serve with raita and salad for a complete meal."
      },
      {
        "id": 3,
        "dishName": "Butter Chicken",
        "imgURL": "https://media.istockphoto.com/id/1170729895/photo/indian-butter-chicken-horizontal-photo.jpg?s=612x612&w=0&k=20&c=4bZViynoVnP1HaWHIY1k5FvW-dj9DM2EOMHbKnAqYZ4=",
        "description": "Butter chicken, also known as Murgh Makhani, features tender chicken pieces marinated in yogurt and spices, then cooked in a creamy tomato sauce. Serve with naan or rice for a delightful experience."
      }, {
        "id": 4,
        "dishName": "Samosa",
        "imgURL": "https://www.indianhealthyrecipes.com/wp-content/uploads/2022/09/samosa-recipe.jpg",
        "description": "Samosas are deep-fried pastry pockets filled with a savory mixture of spiced potatoes, peas, and sometimes meat. Crispy on the outside and soft on the inside, they are often served with chutney for dipping."
      }, {
        "id": 5,
        "dishName": "Paneer Tikka",
        "imgURL": "https://img.onmanorama.com/content/dam/mm/en/food/recipe/images/2024/1/3/paneer-tikka.jpg",
        "description": "Paneer tikka consists of marinated paneer cubes and vegetables grilled or baked until charred. The marinade, made with yogurt and spices, imparts a smoky flavor, making it a popular starter or appetizer."
      }
    ])
  const [selectedDish, setselectedDish] = useState({})
  console.log("selectedDish", selectedDish);

  let getSelectedDish = (dishData) => {
    // console.log("getSelectedDish executed",dishData);
    setselectedDish(dishData)
  }

  return (
    <div className="App">
      <NavbarComp />

      <div className='recipe-container'>
        <div className='recipe-list-left'>
        <RecipeList allRecipeData={allRecipeData} getSelectedDish={getSelectedDish} />
        </div>

       <div className='recipe-list-right'>
        {Object.keys(selectedDish).length>0 &&  
        <RecipeDescription selectedDish={selectedDish} />}
       
       </div>
      </div>
    </div>
  );
}

export default App;
